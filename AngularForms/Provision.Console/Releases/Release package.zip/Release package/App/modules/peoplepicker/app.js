﻿(function () {
    'use strict';        
    var app = angular.module('app', [
		'ngSanitize',
      	'ngResource',	
	   	'ui.People'
    ]);
})();